import Foundation
import SpriteKit
import GameplayKit


public class GameScene: SKScene {

//FOR THE GALAXY BACKGROUND: thanks to Adrian Pelletier, from unsplash.com
	
//adding elements of class Planet: internal planets' sizes are on scale among them, external planets' sizes are on scale among them
//All planets velocities are on scale

	var mercury = Planet(name: "Mercury", planetRadius: 3.825, orbitRadius: 58, planetTextureName: "Textures/mercury.png", planetRotation: 0.24)
	
	var venus = Planet(name: "Venus", planetRadius:9.488, orbitRadius: 70, planetTextureName: "Textures/venus.png", planetRotation: 0.61)
	
	var earth = Planet(name: "Earth", planetRadius: 10, orbitRadius: 85 , planetTextureName:"Textures/earth.png",planetRotation: 1)
	
	var mars = Planet(name: "Mars", planetRadius: 5.32, orbitRadius: 100, planetTextureName: "Textures/mars.png", planetRotation: 1.88)
	
	var jupiter = Planet(name: "Jupiter", planetRadius: 60, orbitRadius: 170, planetTextureName: "Textures/jupiter.png", planetRotation:11.86)
	
	var saturn = Planet(name: "Saturn", planetRadius: 50, orbitRadius: 240, planetTextureName: "Textures/saturn.png", planetRotation: 29.45)
	
	var uranus = Planet(name: "Uranus", planetRadius: 21.4, orbitRadius: 290, planetTextureName: "Textures/Uranus.png", planetRotation: 84.0)
	
	var neptune = Planet(name: "Neptune", planetRadius: 20.8, orbitRadius: 340, planetTextureName: "Textures/Neptune.png", planetRotation: 165.0)
	
	//This var will be used to let the user do things in the scene by tapping on it(to count the number of taps)
	var cont = 0
	
	//Provides some descriptions
	let label = SKLabelNode(fontNamed:"System-Heavy")
	
	//adding space background to the scene
	let background = SKSpriteNode(imageNamed:"Textures/space.png")
	
	//adding camera to the scene
	let cam = SKCameraNode()
	
	override public func didMove(to view: SKView) {

		background.size = self.frame.size
		self.addChild(background)
		
		self.camera = cam
		cam.position = CGPoint(x:self.frame.midX, y:self.frame.midY)
		self.addChild(cam)
		
		//introduction
		label.text = "Welcome to the Solar System Simulator.\nTap on the Sun to start your journey."
		label.numberOfLines = 2
		label.fontColor = UIColor.white
		label.position = CGPoint(x:10, y:(-0.625*(self.frame.maxY)))
		
		//see SKLabelExtension.swift
		label.fitToWidth(maxWidth: self.frame.maxX)
		label.fitToHeight(maxHeight: self.frame.maxY)
		print(label.fontSize)
		
		//Planets will rotate "under" the label
		label.zPosition = 4
		background.addChild(label)
		
		//positioning Sun in the middle of the system
		let sun = SKSpriteNode(imageNamed: "Textures/sun.png")
		sun.position = CGPoint(x:0,y:0)
		sun.size = CGSize(width: 100, height: 100)
		
		//initial alpha
		sun.alpha = 1.0
		
		//let the sun shine!
		let brightness = SKAction.sequence([SKAction.fadeAlpha(to: 0.75, duration: 3), SKAction.fadeAlpha(to: 1.0, duration:3)])
		sun.run(SKAction.repeatForever(brightness))
		
		//add sun to the scene
		self.addChild(sun)
	}
	
	func drawOrbit(radius:CGFloat,isOrbitHidden:Bool)
	{
		//draw an orbit
		let path = CGMutablePath()
		let origin = CGPoint(x: 0, y: 0)
		path.addArc(center: origin , radius: radius, startAngle: 0, endAngle: CGFloat(Double.pi)*2, clockwise: false)
		path.closeSubpath()
		let pathNode = SKShapeNode(path:path)
		
		//adding the orbit to the background
		background.addChild(pathNode)
		pathNode.isHidden = isOrbitHidden
		
		//if the orbit is visible(isOrbitHidden = true),this will be its color(very thin gray)
		pathNode.strokeColor = UIColor.init(red: 100/255.0, green: 100/255.0, blue: 100/255.0, alpha: 1.0)
	}
	
	func drawPlanet(orbit:CGFloat,radius:CGFloat,duration:TimeInterval,textureName:String)
	{
		//draw the planet
		let planet = SKSpriteNode()
		let planetNode = SKSpriteNode(imageNamed: textureName)
		planetNode.position = CGPoint(x:orbit,y:0)
		planetNode.size = CGSize(width: radius, height:radius)
		
		//add the planet to the orbit
		background.addChild(planet)
		planet.addChild(planetNode)
		
		let rotation = SKAction.rotate(byAngle: 1, duration: duration)
		
		//planet rotates on its orbit
		planet.run(SKAction.repeatForever(rotation))
		
		//planet rotates on its axis
		planetNode.run(SKAction.repeatForever(rotation))
		
	}
	
	//The user will get a new planet and a specific description after every tap(the var cont will count them)
	//from Mercury to Mars
	func showInternalPlanets()
	{
		//after first tap, the camera will zoom to properly display internal planets
		cam.run(SKAction.scaleX(to:0.4,duration:1.5))
		cam.run(SKAction.scaleY(to:0.4,duration:1.5))
		
		if cont == 0
		{
			//Showing Mercury
			drawOrbit(radius: mercury.orbitRadius,isOrbitHidden:true)
			
			drawPlanet(orbit: self.mercury.orbitRadius,
					   radius: mercury.planetRadius,
					   duration: mercury.planetRotation,
					   textureName:mercury.planetTextureName)
			
			label.position = CGPoint(x:5,
									 y:10-self.frame.maxY/3)
			
			//reducing the font size to fit new scene
			label.fitToWidth(maxWidth:3*self.frame.maxX)
			label.fitToHeight(maxHeight:3*self.frame.maxY)
			print(label.fontSize)
			
			//description
			label.text = "Mercury\nMercury is the smallest and innermost planet\nof the Solar System."
			label.numberOfLines = 3
			
			//to move to next planet
			cont += 1
			print(cont)
		}
		else if cont == 1
		{
			//Showing Venus
			drawOrbit(radius: self.venus.orbitRadius,isOrbitHidden:true)
			drawPlanet(orbit: venus.orbitRadius, radius: venus.planetRadius,
					   duration: venus.planetRotation,textureName:venus.planetTextureName)
			
			//description
			label.text = "Venus\nUnlike the other planets,it rotates clockwise,\nso on its surface the Sun rises in the west\nand set in the east"
			label.numberOfLines = 3
			print(label.fontSize)
			
			//to move to next planet
			cont += 1
			print(cont)
		}
		else if cont == 2
		{
			//Showing Earth:here we are xD
			drawOrbit(radius: self.earth.orbitRadius,isOrbitHidden:true)
			drawPlanet(orbit: earth.orbitRadius, radius: earth.planetRadius,
					   duration: earth.planetRotation,textureName:earth.planetTextureName)
			
			//description
			label.text = "Earth\nEarth is the only planet to host life: it\nis 150 milions km away from the Sun"
			label.numberOfLines = 3
			print(label.fontSize)
			
			//to move to next planet
			cont += 1
			print(cont)
		}
		else if cont == 3
		{
			//Showing Mars
			drawOrbit(radius: self.mars.orbitRadius,isOrbitHidden:true)
			drawPlanet(orbit: mars.orbitRadius, radius: mars.planetRadius,
					   duration: mars.planetRotation,textureName:mars.planetTextureName)
			
			//description
			label.text = "Mars\nMars typical red color is due to the presence\nof great amounts of rust on its surface"
			label.numberOfLines = 3
			print(label.fontSize)
			
			//to move to next planet
			cont += 1
			print(cont)
		}
	}
	
	func showExternalPlanets()
	//From Jupiter to Neptune
	{
		if cont == 9
		{
			//Camera will zoom out to show Jupiter
			cam.run(SKAction.scaleX(to:0.7,duration:1.5))
			cam.run(SKAction.scaleY(to:0.7,duration:1.5))
			
			//Showing Jupiter
			drawOrbit(radius: self.jupiter.orbitRadius,isOrbitHidden:true)
			drawPlanet(orbit: jupiter.orbitRadius, radius: jupiter.planetRadius,
					   duration: jupiter.planetRotation,textureName:jupiter.planetTextureName)
			
			//description
			label.text = "Jupiter\nJupiter is the biggest planet in the Solar System:\nif it was only 80 times bigger, it would be a star"
			label.numberOfLines = 3
			
			//adapting label to new displayed scene
			label.position = CGPoint(x:5,y:-self.frame.maxY/2)
			
			//see SKLabelExtension.swift
			label.fitToWideSceneWidth(scene:7*self.frame.maxX/10)
			label.fitToWideSceneHeight(scene:7*self.frame.maxY/10)
			print(label.fontSize)
			
			//to move to next planet
			cont += 1
			print(cont)
		}
		else if cont == 10
		{
			//Camera will zoom out to show Saturn
			cam.run(SKAction.scaleX(to:0.8,duration:1.5))
			cam.run(SKAction.scaleY(to:0.8,duration:1.5))
			
			//Showing Saturn
			drawOrbit(radius: self.saturn.orbitRadius,isOrbitHidden:true)
			drawPlanet(orbit: saturn.orbitRadius, radius: saturn.planetRadius,
					   duration: saturn.planetRotation,textureName:saturn.planetTextureName)
			
			//description
			label.text = "Saturn\nSaturn's famous rings are mostly composed by\nrocks,ice and dust"
			label.numberOfLines = 3
			
			//adapting label to new displayed scene
			label.position = CGPoint(x:5 ,y:-5*self.frame.maxY/8)
			label.fitToWideSceneWidth(scene:7*self.frame.maxX/10)
			label.fitToWideSceneHeight(scene:7*self.frame.maxY/10)
			print(label.fontSize)
			
			//to move to next planet
			cont += 1
			print(cont)
		}
		else if cont == 11
		{
			//Camera will zoom out to show Uranus
			cam.run(SKAction.scaleX(to:0.9,duration:1.5))
			cam.run(SKAction.scaleY(to:0.9,duration:1.5))
			
			//Showing Uranus
			drawOrbit(radius: self.uranus.orbitRadius,isOrbitHidden:true)
			drawPlanet(orbit: uranus.orbitRadius, radius: uranus.planetRadius,
					   duration: uranus.planetRotation,textureName:uranus.planetTextureName)
			
			//description
			label.text = "Uranus\nUranus' axis is titled sideways: its poles lie where\nthe other planets have their equators"
			label.numberOfLines = 3
			
			//adapting label to new displayed scene
			label.position = CGPoint(x:5 ,y:-15-5*self.frame.maxY/8)
			label.fitToWideSceneWidth(scene:7*self.frame.maxX/10)
			label.fitToWideSceneHeight(scene:7*self.frame.maxY/10)
			print(label.fontSize)
			
			//to move to next planet
			cont += 1
			print(cont)
		}
		else if cont == 12
		{
			//Final camera zoom
			cam.run(SKAction.scaleX(to:1,duration:1.5))
			cam.run(SKAction.scaleY(to:1,duration:1.5))
			
			//Showing Neptune
			drawOrbit(radius: self.neptune.orbitRadius,isOrbitHidden:true)
			drawPlanet(orbit: neptune.orbitRadius, radius: neptune.planetRadius,
					   duration: neptune.planetRotation,textureName:neptune.planetTextureName)
			
			//description
			label.text = "Neptune\nNeptune storms are the worst in the Solar\nSystem: winds' speed can get as high as\n2100 km/h"
			label.numberOfLines = 4
			
			//adapting label to new displayed scene
			label.position = CGPoint(x:5 ,y:-3*self.frame.maxY/4)
			label.fitToWideSceneWidth(scene:7*self.frame.maxX/10)
			label.fitToWideSceneHeight(scene:7*self.frame.maxY/10)
			print(label.fontSize)
			
			//next scene
			cont += 1
			print(cont)
		}
	}
	
	//to draw a little brown circle to use as an asteroid
	func drawAsteroid(orbit:CGFloat,radius:CGFloat,duration:TimeInterval)
	{
		//drawing asteroid and its orbit
		let asteroid = SKSpriteNode()
		let asteroidNode = SKSpriteNode()
		asteroidNode.position = CGPoint(x:orbit,y:0)
		
		let asteroidPath = CGMutablePath()
		let origin = CGPoint(x: 0, y: 0)
		asteroidPath.addArc(center: origin , radius: radius, startAngle: 0, endAngle: CGFloat(Double.pi)*2, clockwise: false)
		asteroidPath.closeSubpath()
		
		let asteroidPathNode = SKShapeNode(path:asteroidPath)
		
		//giving asteroid a brown color
		asteroidPathNode.fillColor = UIColor.brown
		//let's avoid contacts!
		asteroidPathNode.zPosition = 2.5
		
		//adding asteroid to the scene
		background.addChild(asteroid)
		asteroid.addChild(asteroidNode)
		asteroidNode.addChild(asteroidPathNode)
		
		let rotation = SKAction.rotate(byAngle: 1, duration: duration)
		
		//asteroid rotates on its orbit
		asteroid.run(SKAction.repeatForever(rotation))
		
		//asteroid rotates on its axis
		asteroidNode.run(SKAction.repeatForever(rotation))
	}
	
	//To draw a comet
	func drawComet()
	{
		//draw the orbit of the comet(not visible!)
		var radius = CGFloat()
		radius = 310.0
		let orbitPath = CGMutablePath()
		let origin = CGPoint(x: -170, y: -170)
		orbitPath.addArc(center: origin , radius: radius, startAngle: 0, endAngle: CGFloat(Double.pi)*2, clockwise: false)
		orbitPath.closeSubpath()
		let orbitNode = SKShapeNode(path: orbitPath)
		orbitNode.isHidden = true
		
		//draw the comet
		let cometNode = SKSpriteNode(imageNamed:"Textures/Comet.png")
		cometNode.size = CGSize(width:70,height:70)
		cometNode.zPosition = 1.5
		cometNode.alpha = 0.3
		
		//the comet will be brighter approaching the sun, than it will slowly disappear
		cometNode.run(SKAction.sequence([SKAction.fadeIn(withDuration: 5),
										 SKAction.wait(forDuration: 8),
										 SKAction.fadeOut(withDuration:7)]))
		
		//the comet will follow its own orbit
		let movement = SKAction.follow(orbitPath, asOffset: false, orientToPath: false, speed: 30)
		cometNode.run(movement)
		
		//the comet will slowly rotate on itself
		let rotation = SKAction.rotate(byAngle:1,duration:100)
		cometNode.run(rotation)
		cometNode.run(SKAction.repeatForever(rotation))
		
		//adding the comet to the scene
		background.addChild(orbitNode)
		background.addChild(cometNode)
		
	}

	override public func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
		//in the first part, every tap will be linked to a new planet...
		if cont < 4
		{
			showInternalPlanets()
		}
		
		//...than, an asteroid will be shown between Mars and Jupiter...
		else if cont == 4
		{
			drawAsteroid(orbit: 120, radius: 2, duration: 8)
				
			//The camera will zoom to properly show asteroids
			cam.run(SKAction.scaleX(to:0.5,duration:1.5))
			cam.run(SKAction.scaleY(to:0.5,duration:1.5))
			
			//description
			label.text = "Planets are not the only objects in the\nSolar System. Tap to add asteroids!"
			
			//adapting label to new displayed scene
			label.position = CGPoint(x: 0, y:-3*self.frame.maxY/8)
			label.fontSize = 14
			print(label.fontSize)
			
			//next scene
			cont += 1
			print(cont)
		}
			
			//...and other two will follow...
			else if cont < 7
		{
			drawAsteroid(orbit: 120, radius: 2, duration: 8)
			
			label.text = "Planets are not the only objects in the\nSolar System. Tap to add asteroids!"
			label.numberOfLines = 2
			print(label.fontSize)
			
			cont += 1
			print(cont)
		}
			
		//...the camera will zoom out to show two more asteroids, the label will change...
		else if cont == 7
		{
			cam.run(SKAction.scaleX(to:0.6,duration:1.5))
			cam.run(SKAction.scaleY(to:0.6,duration:1.5))
			
			drawAsteroid(orbit: 140,radius:2,duration:8)
			
			label.position = CGPoint(x: 0, y: -20-3*self.frame.maxY/8)
			label.fontSize = 17
			label.text = "Most of them are between Mars and\nJupiter, but they can be everywhere!"
			
			cont += 1
			print(cont)
		}
		else if cont < 9
		{
			drawAsteroid(orbit: 140,radius:2,duration:8)
			
			label.text = "Most of them are between Mars and\nJupiter, but they can be everywhere!"
			label.numberOfLines = 2
			print(label.fontSize)
			
			cont += 1
			print(cont)
		}
			
		//...than, the remaining planets will be displayed...
		else if cont < 13
		{
			showExternalPlanets()
		}
			
		//creating suspence...
		else if cont == 13
		{
			label.text = "Up next, a little surprise for the romantic ones..."
			
			//next scene
			cont += 1
			print(cont)
		}

		//...hurry up,make a wish :-)
			else if cont == 14
		{
			drawComet()
			
			//description
			label.text = "Comets are basically iced rocks that become\nhot when they approach the Sun.\nTheir orbit shape can be really, really strange!"
			label.numberOfLines = 3
			
			//next scene
			cont += 1
			print(cont)
		}

		//...and that's all,folks!
		else if cont == 15
		{
			//description
			label.text = "Your journey is over, but just one more\nthing before you leave..."
			label.numberOfLines = 2
			
			//next scene
			cont += 1
			print(cont)
		}

		else if cont == 16
		{
			//description
			label.text = "Remember to look up at the stars, not down\nto your feet.\n(Stephen Hawking)"
			label.numberOfLines = 3
			
			//next scene
			cont+=1
			print(cont)
		}
			
		//final scene with "alien" planet set by the user
		else if cont == 17
		{
			//removes all the elements in the scene to display only the sun and user-customed planet
			background.removeAllChildren()
			
			//creating new element of class Planet
			let newPlanet = Planet(name: "AlienPlanet", planetRadius: Settings.shared.rad,orbitRadius: Settings.shared.orb ,planetTextureName: "Textures/alienPlanet.png", planetRotation: Settings.shared.speed)
			
			//draw custom planet with a visible orbit
			drawOrbit(radius:newPlanet.orbitRadius,isOrbitHidden:false)
		drawPlanet(orbit:newPlanet.orbitRadius,radius:newPlanet.planetRadius,duration:newPlanet.planetRotation,textureName:newPlanet.planetTextureName)
			
			//recreating label(it was dismissed by the previous .removeAllChildren!)
			background.addChild(label)
			label.text = "Now, enjoy your custom planet!"
			label.fontColor = UIColor.white
			label.position = CGPoint(x:10, y:(-3*(self.frame.maxY)/4))
			label.zPosition = 4
			
			cont += 1
			print(cont)
			print(newPlanet.orbitRadius)
			print(newPlanet.planetRadius)
			print(newPlanet.planetRotation)
		}

	}

}





