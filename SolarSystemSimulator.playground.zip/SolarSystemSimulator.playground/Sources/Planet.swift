import Foundation
import UIKit

//Every planet will be given a name, a radius, the radius and the speed of its orbit around the Sun, and obiouvsly an image
public class Planet
{
	public var name = String()
	public var planetRadius = CGFloat()
	public var orbitRadius = CGFloat()
	public var planetTextureName = String()
	public var planetRotation = TimeInterval()
	
	public init(name:String,planetRadius:CGFloat,orbitRadius:CGFloat,planetTextureName:String,planetRotation:TimeInterval)
	{
		self.name = name
		self.planetRadius = planetRadius
		self.orbitRadius = orbitRadius
		self.planetTextureName = planetTextureName
		self.planetRotation = planetRotation
	}
	
}



