import Foundation
import AVFoundation

//Adding the possibility to let the user set a background music


/*Music credits:
For "NeilSoundtrack" : ARTIST: PHILLIP GROSS - SONG: "E-MUSIK"
http://freemusicarchive.org/music/Phillip_Gross/Quart/Phillip_Gross_Quart_-_06_E-MusikFor

For "BuzzSoundtrack" : ARTIST: BLUE DOT SESSIONS - SONG: "COME AS YOU ARE"
https://www.sessions.blue
*/

var backgroundSound : AVAudioPlayer?

public func NeilSoundtrack()
{
	
	guard let url = Bundle.main.url(forResource:"Soundtracks/PhilipGross",withExtension: "mp3") else
	{
		return
	}
	do
	{
		try AVAudioSession.sharedInstance().setCategory(AVAudioSessionCategoryPlayback)
		try AVAudioSession.sharedInstance().setActive(true)
		
		backgroundSound = try AVAudioPlayer(contentsOf: url, fileTypeHint: AVFileType.mp3.rawValue)
		
		guard let backgroundSound = backgroundSound else
		{
			return
		}
		
		backgroundSound.play()
		print("play1!")
		
	} catch let error {
		// couldn't load file
		print(error.localizedDescription)
	}
}


public func BuzzSoundtrack()
{
	
	guard let url = Bundle.main.url(forResource:"Soundtracks/BlueDotSessions",withExtension: "mp3") else
	{
		return
	}
	do
	{
		try AVAudioSession.sharedInstance().setCategory(AVAudioSessionCategoryPlayback)
		try AVAudioSession.sharedInstance().setActive(true)
		
		backgroundSound = try AVAudioPlayer(contentsOf: url, fileTypeHint: AVFileType.mp3.rawValue)
		
		guard let backgroundSound = backgroundSound else
		{
			return
		}
		
		backgroundSound.play()
		print("play2!")
		
		
	} catch let error {
		// couldn't load file
		print(error.localizedDescription)
	}
}
