import Foundation
import SpriteKit

//To handle the dimension of label font in the scene, depending on the scene dimensions

public extension SKLabelNode {
	func fitToWidth(maxWidth:CGFloat){
		if frame.size.width <= maxWidth {
			fontSize-=7.0
		}
	}
	
	func fitToHeight(maxHeight:CGFloat){
		if frame.size.height <= maxHeight {
			fontSize-=7.0
		}
	}
	
	
	func fitToWideSceneWidth(scene:CGFloat)
	{
		if frame.size.width >= scene
		{
			fontSize+=2
		}
	}
	
	func fitToWideSceneHeight(scene:CGFloat)
	{
		if frame.size.height >= scene
		{
			fontSize+=2
		}
	}
	
}
