import Foundation
import UIKit

/*To handle the elements that the user will be given to the "alien" planet in the final scene(radius of the planet,
orbit radius and its speed*/

public class Settings {
	
	public static var shared = Settings()
	public var rad = CGFloat()
	public var orb = CGFloat()
	public var speed = TimeInterval()
		
}

