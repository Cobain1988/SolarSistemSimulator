/*:
# Solar System Simulator

- Important:
To fully enjoy the experience, **please use landscape mode in full screen**


Hi, people from planet Earth! Welcome to the *Solar System Simulator*.

Here you can discover some interesting information about the Solar System, in particular:
* Our Star, the Sun
* The eight planets
* Some other objects that are part of the system

**Just tap on the screen to see objects appear in the scene.**

This is also a hands-on experience: if you change the parameters in the box below(or you write them, if you're using this playgrpund on Mac), **at the end of your journey** you will visualize a custom planet.
The parameters are:
* Custom planet radius
* Custom planet orbit radius
* Custom planet revolution time (in years: the higher you set, the slower the planet will take to go round the Sun)

Moreover, you can also decide to listen to some of the astronauts' favourite songs during your journey.
To make it real, just tap in the box (if you are on IPad) or write (if you are on Mac) below to select one of the following instructions:
* `NeilSoundtrack()`
* `BuzzSoundtrack()`


For iPad only: To start an amazing journey in the nearby space and see the changes you made, tap on  `Run My Code`

*/
import UIKit

//#-code-completion(everything, hide)
//#-code-completion(identifier, show, NeilSoundtrack(), BuzzSoundtrack())
//#-editable-code Tap here to add a song
//#-end-editable-code

//CHANGE CUSTOM PLANET RADIUS HERE
public var r = CGFloat()
r = /*#-editable-code*/50/*#-end-editable-code*/

//CHANGE CUSTOM PLANET ORBIT RADIUS HERE
public var o = CGFloat()
o = /*#-editable-code*/150/*#-end-editable-code*/

//CHANGE CUSTOM PLANET REVOLUTION TIME HERE
public var revTime = TimeInterval()
revTime = /*#-editable-code*/4/*#-end-editable-code*/


//#-hidden-code
import PlaygroundSupport
import SpriteKit
import GameplayKit

//let viewSize = CGSize(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
//iPad debugging

let viewSize = CGSize(width:750,height:750)
//Mac debugging

let origin = CGPoint(x: 0, y: 0)
let sceneView = SKView(frame: CGRect(origin: origin, size: viewSize))
let scene = GameScene(fileNamed: "GameScene")

scene?.scaleMode = .aspectFill
sceneView.autoresizingMask = [.flexibleWidth,.flexibleHeight]
sceneView.presentScene(scene)
sceneView.translatesAutoresizingMaskIntoConstraints = false

PlaygroundPage.current.liveView = sceneView
PlaygroundPage.current.needsIndefiniteExecution = true

Settings.shared.rad = r
Settings.shared.orb = o
Settings.shared.speed = revTime
//#-end-hidden-code


BuzzSoundtrack()















